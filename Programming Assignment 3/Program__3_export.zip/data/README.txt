The .distsim output file was produced using k=10 as the window size parameter.
