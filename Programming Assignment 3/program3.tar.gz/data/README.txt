The .distsim output file was produced using k=10 as the window size parameter.


All my code and related files are inside data folder given by you. So after you unzip my
submission go to the data folder!

Lesk algorithm: 
To run the program:
# python3 lesk.pytest.txt definitions.txtstopwords.txt
output would be there in "test.txt.lesk"


Nearest-neighbor Algorithm
run
# python distsim.py train.txt test.txt stopwords.txt 10
output would be collected in "test.txt.distsim"

